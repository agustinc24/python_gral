from setuptools import setup

setup(name="paquetecalculos", version="1.0", description="Paquete de redondeo y potencia", author="Cava", author_email="asfd", url="www.xvideos.com",
	packages=["calculos","calculos.redondeo_potencia"])