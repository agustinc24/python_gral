def potencia(base,exponente):
	print("El resultado de la potencia es:",base**exponente)

def redondear(num):
	print("El numero redondeado es:",round(num))